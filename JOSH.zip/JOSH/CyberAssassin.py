import nmap
import os
import requests
from tqdm import tqdm
from ipaddress import IPv4Network

# Get the range of IP addresses to scan
ip_range = input('Enter the IP range to scan (e.g., 192.168.1.0/24): ')

def scan(ip):
    nm = nmap.PortScanner()
    nm.scan(ip, arguments='-sS -A -Pn')
    if nm[ip].state() != 'up':
        print(ip + ' is down')
        return
    else:
        print(ip + ' is up')
    for port in nm[ip]['tcp']:
        if 'open' in nm[ip]['tcp'][port]['state']:
            print('Port ' + str(port) + ' is open')
            try:
                service = nm[ip]['tcp'][port]['name']
                version = nm[ip]['tcp'][port]['version']
                product = nm[ip]['tcp'][port]['product']
                print(service + ' ' + version + ' ' + product)
            except KeyError:
                pass
            try:
                exploit = find_exploit(product, version)
                if exploit is not None:
                    print('Potential exploit found: ' + exploit)
            except requests.exceptions.RequestException:
                pass

def find_exploit(product, version):
    url = 'https://www.exploit-db.com/search'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    data = {'q': product + ' ' + version, 'action': 'search'}
    r = requests.post(url, headers=headers, data=data)
    if r.status_code == 200:
        exploit = r.content.decode('utf-8').split('https://www.exploit-db.com/exploits/')[1].split('/')[0]
        return exploit
    else:
        return None

if __name__ == '__main__':
    # Create a list of IP addresses from the given IP range
    ip_list = [str(ip) for ip in IPv4Network(ip_range)]

    # Use tqdm to display a progress bar for scanning multiple IP addresses
    for ip in tqdm(ip_list, desc="Scanning IP addresses", ncols=100):
        scan(ip)
