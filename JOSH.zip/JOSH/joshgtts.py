import random
import re
from collections import defaultdict
import speech_recognition as sr
import subprocess
import datetime
import webbrowser
import pyaudio
import argparse
import cmd
import nltk
import requests
import os
import time
import optparse
import re
import site
import random
import socket
import webbrowser
import subprocess
from subprocess import call
from bs4 import BeautifulSoup
import numpy as np
import datetime
import transformers
import wikipedia
import pywhatkit
import pyjokes
import platform
import threading
from gtts import gTTS
from playsound import playsound
from pydub import AudioSegment



print('''                                                                                                                                                                
                  JJJJJJJJJJJ     OOOOOOOOO        SSSSSSSSSSSSSSS HHHHHHHHH     HHHHHHHHH
                  J:::::::::J   OO:::::::::OO    SS:::::::::::::::SH:::::::H     H:::::::H
                  J:::::::::J OO:::::::::::::OO S:::::SSSSSS::::::SH:::::::H     H:::::::H
                  JJ:::::::JJO:::::::OOO:::::::OS:::::S     SSSSSSSHH::::::H     H::::::HH
                    J:::::J  O::::::O   O::::::OS:::::S              H:::::H     H:::::H  
                    J:::::J  O:::::O     O:::::OS:::::S              H:::::H     H:::::H  
                    J:::::J  O:::::O     O:::::O S::::SSSS           H::::::HHHHH::::::H  
                    J:::::j  O:::::O     O:::::O  SS::::::SSSSS      H:::::::::::::::::H  
                    J:::::J  O:::::O     O:::::O    SSS::::::::SS    H:::::::::::::::::H  
        JJJJJJJ     J:::::J  O:::::O     O:::::O       SSSSSS::::S   H::::::HHHHH::::::H  
        J:::::J     J:::::J  O:::::O     O:::::O            S:::::S  H:::::H     H:::::H  
        J::::::J   J::::::J  O::::::O   O::::::O            S:::::S  H:::::H     H:::::H  
        J:::::::JJJ:::::::J  O:::::::OOO:::::::OSSSSSSS     S:::::SHH::::::H     H::::::HH
         JJ:::::::::::::JJ    OO:::::::::::::OO S::::::SSSSSS:::::SH:::::::H     H:::::::H
           JJ:::::::::JJ        OO:::::::::OO   S:::::::::::::::SS H:::::::H     H:::::::H
             JJJJJJJJJ            OOOOOOOOO      SSSSSSSSSSSSSSS   HHHHHHHHH     HHHHHHHHH
''')



MASTER = "Blake"

def wishme():
    hour = int(datetime.datetime.now().hour)

    if hour>=0 and hour <12:
        speak("Good Morning "+ MASTER)
    elif hour>=12 and hour <18:
        speak("Good Afternoon "+ MASTER)
    else:
        speak("Good Evening "+ MASTER)
        

def speak(text, speed=2.5):
    tts = gTTS(text=text, lang='en')
    filename = "audio.mp3"
    tts.save(filename)  # Save the speech audio into a file
    playsound(filename)  # Use playsound to play the saved mp3 file
    os.remove(filename)  # Remove the file after playing it
    
class SimpleLLM:
    def __init__(self, order=1):
        print("----------------------------")
        print("----- Starting up Josh -----")
        print("----------------------------")
        wishme()
        #speak(f"Hello I am Josh, what can I do for you {MASTER}?")
        self.order = order
        self.model = defaultdict(list)


    def train(self, text):
        words = re.findall(r'\w+', text.lower())
        for i in range(len(words) - self.order):
            key = tuple(words[i:i+self.order])
            value = words[i+self.order]
            self.model[key].append(value)

    def generate_text(self, seed_words, length=50):
        current_key = tuple(seed_words[-self.order:])
        generated_words = list(current_key)

        for _ in range(length):
            next_word_candidates = self.model[current_key]
            if not next_word_candidates:
                break

            next_word = random.choice(next_word_candidates)
            generated_words.append(next_word)
            current_key = tuple(generated_words[-self.order:])

        return " ".join(generated_words)

    def handle_intent(self, intent, app_name=None):
        if intent == "greeting":
            greetingjosh = ["Welcome", "hey there", "Welcome back", "whats up", "Hello! How can I help you?"]
            greetingstatement = (random.choice(greetingjosh))
            return speak(greetingstatement + f"{MASTER}")
        
        elif intent == "count_words":
            return f"The training data has {self.get_word_count()} words."
        
        elif intent == "rudeaf":
            rudeafjosh = ["thats not very nice", "im sorry im not being helpful", "its important to be kind"]
            rudeafstatement = (random.choice(rudeafjosh))
            return speak(rudeafstatement + f"{MASTER}")
        
        elif intent == "open_app":
            if app_name:
                return self.open_app(app_name)
            else:
                return "Please specify an application to open."
            
        elif intent == "welcome":
            urwelcome = ["you're welcome" , "anytime", "no problem", "cool", "I'm here if you need me for anything else sir"]
            gratitude = (random.choice(urwelcome))
            return speak(gratitude + f"{MASTER}")
        else:
            return "I'm sorry, I don't understand."

    def get_word_count(self):
        return sum(len(value) for value in self.model.values())

    def open_app(self, app_name):
        try:
            subprocess.Popen(["open", "-a", app_name])
            return f"Opening {app_name}..."
        except FileNotFoundError:
            return f"Sorry, I could not find the {app_name} application."
        
    def action_time(self):
        time = datetime.datetime.now().strftime("%H:%M")
        speak(f"The current Time is {time}")
        return f"The current Time is {time}"

    def cyberassassin():
        speak("starting your tool")
        os.system('sudo python3 /Users/blakeweiss/JOSH/CyberAssassin.py')
            
    def getthenews(self):
        url = ('https://www.bbc.com/news')
        response = requests.get(url)

        soup = BeautifulSoup(response.text, 'html.parser')
        headlinesnews = soup.find('body').find_all('h3')
        unwantedbs = ['BBC World News TV', 'BBC World Service Radio',
                        'News daily newsletter', 'Mobile app', 'Get in touch']

        for x in list(dict.fromkeys(headlinesnews)):
            if x.text.strip() not in unwantedbs:
                speak(x.text.strip())
                
    def getPerson(self, spoken_text):

        wordList = spoken_text.lower().split() 

        for i in range(0, len(wordList)):
            if i + 3 <= len(wordList) - 1 and wordList[i].lower() == 'who' and wordList[i+1].lower() == 'is':
                return wordList[i+2] + ' ' + wordList[i+3]
            
    def cyberassassin():
        speak("starting your tool")
        os.system('sudo python3 /Users/blakeweiss/JOSH/CyberAssassin.py')
        
    def pentestingkit():
            time.sleep(1)
            speak("There are many tools avaiable for use")
            print("1 routersploit")
            print("2 pentestiptrackerai")
            print("3 passwordcheckerai")
            print("4 metasploit")
            print("5 pentestportscannerai")
            print("6 reversedns")
            print("7 nmap")
            print("8 findpeople")
            print("9 dosser")
            speak(f"Sorry {MASTER} your going to have to enter what you want manually")
            startkit = input('Your choice: ')

            if startkit == "1":
                speak("Starting routersploit")
                speak("Do you have routerspolit installed?")
                routersploitinstall = input("y/n: ")
    
            if routersploitinstall == "y":
                os.system('cd /Users/blakeweiss/Desktop/JOSH')
                speak('routersploit file open')
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/routersploitvoiceai/rsf.py')
        
            if routersploitinstall == "n":
                os.system('git clone https://github.com/threat9/routersploit.git')
                os.system('cd routersploit')
                os.system('python3 rsf.py')
                
            if startkit == "2":
                speak("starting ip tracker")
                time.sleep(1)
                os.system('clear')
                speak("Enter ip you want to track manually")
                iptrack = input("Enter: ")
                #import pentestiptracker.py
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/iptrack.py ' + '-v ' + iptrack)

            if startkit == "3":
                speak("Starting password checker")
                time.sleep(1)
                os.system('clear')
                print('Enter password you want checked manually')
                passwordcheck = input('Your password: ')
                #import passwordcheck.py
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/passwordcheckvoice.py ' + passwordcheck)

            if startkit == "4":
                speak("starting metasploit")
                time.sleep(1)
                os.system('/opt/metasploit-framework/bin/msfconsole')

            if startkit == "5":
                speak("starting pentestportscanner")
                time.sleep(1)
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/pentestportscannervoice.py')

            if startkit == "6":
                speak("starting reversedns")
                time.sleep(1)
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/reversednsvoice.py')

            if startkit == "7":
                speak("Starting nmap")
                time.sleep(1)
                speak("please enter the ip you want to scan manually")
                nmapip = input('The ip you want to scan: ')
                os.system('nmap ' + nmapip)

            if startkit == "8":
                speak("starting findpeople")
                time.sleep(1)
                os.system('python3 /Users/blakeweiss/Desktop/JOSH/findpeoplevoice.py')

            if startkit == "9":
                speak("starting dosser service")
                time.sleep(1)
                print('Which service would you like to use for dossing')
                print('[1] hping3')
                print('[2] reaperdoss')
                dosserchoice = input('Your choice: ')

                if dosserchoice == "1":
                    speak('starting hping3')
                    time.sleep(1)
                    speak("please enter the ip you want to attack enter manually")
                    hpingip = input('Whats the ip: ')
                    speak("how many times do you want to attack enter manually")
                    attacktime = input('Amount of times: ')
                    time.sleep(1)
                    os.system('sudo hping3 -c ' + attacktime + ' -d 120 -S -w 64 -p 21 --flood --rand-source ' + hpingip) 

                if dosserchoice == "2":
                    speak('starting reaperdosser')
                    os.system('python3 /Users/blakeweiss/Desktop/JOSH/reaperdossvoice.py')

                    
def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Please speak...")
        audio = recognizer.listen(source)

    try:
        recognized_text = recognizer.recognize_google(audio)
        print("You said:", recognized_text)
        return recognized_text
    except sr.UnknownValueError:
        print("Could not understand the audio")
    except sr.RequestError as e:
        print("Error with the request; {0}".format(e))

def extract_intent(text):
    text = text.lower()
    #greeting
    if any(i in text for i in ["hello", "hello there", "hi there", "what's up"]):
        return "greeting", None

    #rudeaf
    if any(i in text for i in ["fuck you", "your a piece of shit", "your useless", "your no help"]):
        return "rudeaf", None
                               
                               
    #how many words
    elif "how many words" in text or "word count" in text:
        return "count_words", None

    #thanks/welcome
    if any(i in text for i in ["thank", "thanks", "thank you", "thank you for your help"]):
        return "welcome", None

    #open apps
    elif "open" in text:
        app_name = extract_app_name(text)
        return "open_app", app_name
    else:
        return None, None

def extract_app_name(text):
    words = text.split()
    if "open" in words:
        index = words.index("open")
        if index + 1 < len(words):
            return words[index + 1]
    return None

def close_application(app_name):
    script = f'tell application "{app_name}" to quit'
    try:
        subprocess.run(['osascript', '-e', script])
        #print(f'{app_name} has been closed.')
    except Exception as e:
        print(f'Error closing {app_name}: {e}')
    return "closed"

def listen_for_wake_word():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for wake")
        audio = r.listen(source)

    try:
        intro = r.recognize_google(audio, language='en-us')
        print("Me  --> ", intro)
        return intro
    except:
        print("Me  -->  ERROR")
        return ""
    
if __name__ == "__main__":
    example_text = """
        Once upon a time in a far away land, there lived a wise king who ruled over a vast kingdom. The people of the kingdom were happy and prosperous, thanks to the king's wisdom and fair rule. Many years passed, and the king's fame grew far and wide. Visitors from distant lands traveled to the kingdom to seek the king's counsel and learn from his wisdom. The kingdom flourished under his guidance, and the people lived in harmony with each other and with nature. In time, the king's wisdom became legendary, and his name was celebrated throughout the ages.
    """

    simple_llm = SimpleLLM(order=4)
    simple_llm.train(example_text)

    r = sr.Recognizer()
    
    while True:
        intro = listen_for_wake_word()

        if "Josh" in intro:
            os.system("afplay /Users/blakeweiss/Desktop/JOSH/aibeepmain.mp3")
            print("Taking input")
            with sr.Microphone() as source:
                audiotask = r.listen(source)

            try:
                spoken_text = r.recognize_google(audiotask, language='en-us')
                print("You said:", spoken_text)
            except:
                print("Me  -->  ERROR")
                
            #args for task and other stuff
            if spoken_text:
                simple_llm.train(spoken_text)
                intent, app_name = extract_intent(spoken_text)
                if intent:
                    response = simple_llm.handle_intent(intent, app_name)
                    
                elif "are you there" in spoken_text.lower():
                    speak(f"Im here {MASTER}")
                    

                elif "what does Josh stand for" in spoken_text.lower():
                    speak("Josh stands for Just Ordinary Selfless Helper")
                
                #decrypt stuff
                elif "decrypt" in spoken_text.lower():
                    speak("What is the file you would like to decrypt?")
                    decryptfile = input("Enter file path: ")
                    os.system("ciphey -f " + decryptfile)
                    
                #hide ip
                elif "hide me" in spoken_text.lower():
                    os.system("bash /Users/blakeweiss/Desktop/JOSH/hidemeai.sh")
                    speak("hiding your ip with tor")
                    
                elif "start my pentesting kit" in spoken_text.lower():
                    simple_llm.pentestingkit()
                    
                #time
                elif "time" in spoken_text.lower():
                    response = simple_llm.action_time()

                #run cyberassassin
                elif "run cyber assassin" in spoken_text.lower():
                    simple_llm.cyberassassin()
                    
                #who is
                elif "who is" in spoken_text.lower():
                    person = simple_llm.getPerson(spoken_text)
                    wiki = wikipedia.summary(person, sentences = 2)
                    responsewhois = ("this is") + ' ' + wiki
                    speak(responsewhois)
                    print(responsewhois)

                elif 'tell me a joke' in spoken_text.lower():
                    speak(pyjokes.get_joke())
                
                #the news    
                elif any(i in spoken_text.lower() for i in ["tell me today's news", "tell me the news", "whats the news", "whats happening in the world"]):       
                    speak("telling you the news")
                    simple_llm.getthenews()
                    
                elif any(i in spoken_text.lower() for i in ["how were you made", "what was your purpose", "what was the purpose of you being created"]):
                    howwereyoumade = ["I am a chatbot program with self thinking programing I have many skills avaiable for use.", "Im a ai chatbot program which should act as a assistent for whatever you may need."]
                    joshcreation = (random.choice(howwereyoumade))
                    speak(joshcreation + f"{MASTER}")
                    
                #search stuff
                elif "search" in spoken_text.lower():
                    speak(f'What can I search for you {MASTER}?')
                    with sr.Microphone() as source:
                        speak("Just state what you want to search sir")
                        print("listening")
                        searchaudio = r.listen(source)
                        searchstuff="ERROR"
                    try:
                        searchstuff = r.recognize_google(searchaudio, language='en-us')
                        print("Me  --> ", searchaudio)
                    except:
                        print("Me  -->  ERROR")
                    response = webbrowser.open('https://www.google.com/search?q=' + searchstuff)
                     

                elif any(i in spoken_text.lower() for i in ["whats a good movie", "what are the best movies right now" ,"what are the top ten movies right now", "tell me a good movie to watch"]):
                    goodmovies = ["star wars", "jurrasic park", "clear and present danger", "war dogs", "wolf of wall street", "the big short", "trading places", "the gentlemen", "ferris bullers", "goodfellas", "lord of war", "borat", "marvel", "the hurt locker", "hustle", "forrest gump", "darkest hour", "coming to america", "warren miller movies", "the dictator"]
                    moviechoice = (random.choice(goodmovies))
                    speak("A good movie you could watch is " + moviechoice + f"{MASTER}")    

                #skills avaiable 
                elif "what are your skills" in spoken_text.lower():
                    skillsforuse = 'Hi I am Josh. I can search google' \
                        ' Open apps, Tell you date and time, run chat gpt, run hide me, open pentesting toolkit' \
                        ' Do math calculations, find out who someone is, search something, tell me the news'  \
                        ' Decrypt text, tell a joke' \

                elif "close" in spoken_text.lower():
                    app_name = spoken_text.split("close ")[1]
                    close_application(app_name)
                
                    
                else:
                    seed_words = re.findall(r'\w+', spoken_text.lower())[-simple_llm.order:]
                    response = simple_llm.generate_text(seed_words, length=30)

                print("Response:", response)
                
                
                print("\nContinue the conversation or say 'exit' to stop.")
                if any(i in spoken_text.lower() for i in ["exit"]):
                    ending = ["Have a good day", "Bye", "Goodbye", "See you again soon"]
                    endstatement = (random.choice(ending))
                    speak(endstatement + f"{MASTER}")
                    exit()
